1. 'Nop.Plugin.Payments.eWayHosted' directory contains source code.
2. 'Payments.eWayHosted' contains binaries. Just drop it into \Plugins directory on your server.