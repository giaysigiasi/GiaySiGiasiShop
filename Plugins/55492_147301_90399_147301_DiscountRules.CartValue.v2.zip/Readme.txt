/********************************************************************************

	Developed by Wherrelz IT Solutions Pvt Ltd (www.wherrelz.com)

********************************************************************************/

This package contains only binaries. Unzip it into \Plugins directory of your NopCommerce installation

This Plugin is FREE TO USE. 