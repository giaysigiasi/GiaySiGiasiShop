﻿using System.Collections.Generic;
using Nop.Web.Framework.Mvc;
using Nop.Core.Domain.Catalog;
using Nop.Web.Models.Common;
using Nop.Web.Models.Catalog;

namespace Nop.Plugin.Misc.LiveAnnouncement.Models
{
    public class AnnouncementHomePageModel
    {
        //public TodayOrderDetailListHomePageModel()
        //{
        //    Products = new List<ProductOverviewModel>();
        //}

        //public PagerModel PagerModel { get; set; }
        public bool ShowOrderedProductAtHomePage { get; set; }

        //public List<ProductOverviewModel> Products { get; set; }

        
    }
}