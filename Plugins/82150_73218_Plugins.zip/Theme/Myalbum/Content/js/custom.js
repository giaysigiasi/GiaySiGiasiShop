$(document).ready(function () {
	
	$(".menu-mobile").click(function(){
		$("body").toggleClass("menu-open");
		$(".navigation").append("<div class='black-overlay'></div>");
	});
	$(document).mouseup(function (e) {
		 var popup = $("ul.show-on-mobile");
		 var popup_ovrlay = $(".navigation .black-overlay");
		 if (!$('').is(e.target) && !popup.is(e.target) && popup.has(e.target).length == 0) {
			 //popup.fadeOut("fast");
			 popup.removeClass("show-on-mobile");
			 popup_ovrlay.remove();
			 $("body").removeClass("menu-open");
		 }
	});
	
	var window_width = $(window).width();
	if(window_width < 768){
		var header_height_dyn = $(".header").outerHeight();
		$("body").css("padding-top", header_height_dyn);
		
		$(".pre-header .cart-icon a.toogle-link").click(function(){
			$(".pre-header .cart-icon .cart-box").toggleClass('open');
		});
		
		$(".pre-header .top-links").clone().prependTo(".pre-header .cart-icon .cart-box");
		
		$(".pre-header .cart-icon > a").click(function(){
			$("body").toggleClass("menu-open");
			$(".pre-header").append("<div class='black-overlay'></div>");
		});
		
		$("ul li.menu-dropdown-icon").append("<span class='sub-menu'></span>");
		$("ul li.menu-dropdown-icon span.sub-menu").click(function(){
			$(this).toggleClass('open');
		});
		
		$(document).mouseup(function (e) {
			 var right_menu = $(".pre-header .cart-icon .cart-box.open");
			 var right_ovrlay = $(".pre-header .black-overlay");
			 if (!$('').is(e.target) && !right_menu.is(e.target) && right_menu.has(e.target).length == 0) {
				 //popup.fadeOut("fast");
				 right_menu.removeClass("open");
				 right_ovrlay.remove();
				 $("body").removeClass("menu-open");
			 }
		});
		
		$(window).resize(function(){
			var header_height = $(".header").outerHeight();
			$("body").css("padding-top", header_height);
		});
		
		$(window).scroll(function() {    
			var scroll = $(window).scrollTop();
			if (scroll >= 100) {
				$(".header").addClass("header-shadow");
			}
			else{
				$(".header").removeClass("header-shadow");
			}
		});
		
	}
	else{
		$(".pre-header .cart-icon .cart-box").slideUp();
		$(".pre-header .cart-icon a.toogle-link").click(function(){
			$(".pre-header .cart-icon .cart-box").slideToggle();
			$(".pre-header .cart-icon .cart-box").toggleClass('open');
		});
	}
	
	//Product Listing Sidebar
	//var sidebar_width = $(".sidebar").width();
    //alert(sidebar_width);

	
	//$(".right-content").find(".col-md-4").addClass("col-md-3");


	if (window_width > 768) {
	    $(window).resize(function () {
	        var header_height = $(".header").outerHeight();
	        $("body").css("padding-top", header_height);
	    });

	    var header_height_load = $(".header").outerHeight();
	    $("body").css("padding-top", header_height_load);
	}
	
});


function SlideLeft() {
 
    $(".hide-sidebar").removeClass("loaded");
    $(".hide-sidebar").toggleClass("plus-icon");
    $(".right-content").toggleClass("full");
    $(".sidebar").toggleClass("hide-sidebar");
    $(".right-content").find(".col-sm-6").toggleClass("one-third");
}


if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {}


function isAlpha(parm) { 
    var ValidChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@&,:;(').!%-)(?/+";
    var isAlpha = true;
    var Char;
    for (i = 0; i < parm.length && isAlpha == true; i++) {
        Char = parm.charAt(i);

        if (ValidChars.indexOf(Char) == -1) {         
            isAlpha = false;
        }
    }
    return isAlpha;

}

