--*************************************************************************
--*                                                                       *
--* nopAccelerate - Solr Integration Extension for nopCommerce            *
--* Copyright (c) Xcellence-IT. All Rights Reserved.                      *
--*                                                                       *
--*************************************************************************
--*                                                                       *
--* Email: info@nopaccelerate.com                                         *
--* Website: http://www.nopaccelerate.com                                 *
--*                                                                       *
--*************************************************************************
--*                                                                       *
--* This  software is furnished  under a license  and  may  be  used  and *
--* modified  only in  accordance with the terms of such license and with *
--* the  inclusion of the above  copyright notice.  This software or  any *
--* other copies thereof may not be provided or  otherwise made available *
--* to any  other  person.   No title to and ownership of the software is *
--* hereby transferred.                                                   *
--*                                                                       *
--* You may not reverse  engineer, decompile, defeat  license  encryption *
--* mechanisms  or  disassemble this software product or software product *
--* license.  Xcellence-IT may terminate this license if you don't comply *
--* with  any  of  the  terms and conditions set forth in  our  end  user *
--* license agreement (EULA).  In such event,  licensee  agrees to return *
--* licensor  or destroy  all copies of software  upon termination of the *
--* license.                                                              *
--*                                                                       *
--* Please see the  License file for the full End User License Agreement. *
--* The  complete license agreement is also available on  our  website at *
--* http://www.nopaccelerate.com/terms/				                      *
--*                                                                       *
--*************************************************************************

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[InsertProductDataInIncrementalTable]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[InsertProductDataInIncrementalTable]
GO

/****** Object:  StoredProcedure [dbo].[InsertProductDataInIncrementalTable]    
Script Date: 10/10/2016 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =========================================================================
-- Author:		 XcellenceIT
-- Create date:  08-12-2016
-- Description:	 Insert Product Data In Incremental Solr Product Table
-- Created by:   Kalpesh Boghara
-- =========================================================================
Create procedure [dbo].[InsertProductDataInIncrementalTable]
as
BEGIN

Declare @Id int
Declare @IncrementalRemainingIdFromProduct varchar(max)
Declare @StoreDeleteQuery varchar(max)
Declare @IncrementalAddIdFromProduct varchar(max)


--Delete Data which is not in product table from Incremental_Solr_Product table

set @StoreDeleteQuery = 'update Incremental_Solr_Product set IsDeleted=1
						    WHERE ProductId NOT IN (SELECT Product.Id 
                            FROM Product);'
exec(@StoreDeleteQuery)

--Create temp table 

create table #temp(
productid int
)
 
--Insert productId into #temp which is available in product table but not in Incremental_Solr_Product table

Insert into #temp
select Product.Id from Product 
left join Incremental_Solr_Product ON Incremental_Solr_Product.ProductId = Product.ID
where Incremental_Solr_Product.ProductId is NULL

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT tmp.ProductId,1,0,GETDATE(),s.Id,l.Id from  Language l,  Store s, Product p right join #temp tmp on tmp.ProductId = p.Id  
where p.Deleted = 'False' and p.Published = 'True' and  p.VisibleIndividually = 'True'

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT tmp.ProductId,1,0,GETDATE(),s.Id,l.Id from  Language l,  Store s, Product p right join #temp tmp on tmp.ProductId = p.Id  
where p.Deleted = 'False' and p.Published = 'False' and  p.VisibleIndividually = 'True'

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT tmp.ProductId,1,0,GETDATE(),s.Id,l.Id from  Language l,  Store s, Product p right join #temp tmp on tmp.ProductId = p.Id  
where p.Deleted = 'False' and p.Published = 'True' and  p.VisibleIndividually = 'False'

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT temp.ProductId,1,1,GETDATE(),s.Id,l.Id from  Language l,  Store s, #temp tmp, Product p right join #temp temp on temp.ProductId = p.Id  
where p.Deleted = 'True' and p.Published = 'True' and  p.VisibleIndividually = 'True'

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT tmp.ProductId,1,1,GETDATE(),s.Id,l.Id from  Language l,  Store s, Product p right join #temp tmp on tmp.ProductId = p.Id  
where p.Deleted = 'True' and p.Published = 'False' and  p.VisibleIndividually = 'True' 

Insert into Incremental_Solr_Product(ProductId, SolrStatus, IsDeleted, InTime, StoreId,LanguageId) 
select DISTINCT tmp.ProductId,1,1,GETDATE(),s.Id,l.Id from  Language l,  Store s, Product p right join #temp tmp on tmp.ProductId = p.Id  
where p.Deleted = 'True' and p.Published = 'True' and  p.VisibleIndividually = 'False' 

UPDATE Incremental_Solr_Product
Set IsDeleted=0
where ProductId in (Select p.Id from Product as p where p.LimitedToStores=0)

UPDATE Incremental_Solr_Product
Set IsDeleted=1
where ProductId in (Select p.Id from Product as p where p.Published = 0 OR p.Deleted = 1 OR p.VisibleIndividually = 0)

	drop table #temp
END