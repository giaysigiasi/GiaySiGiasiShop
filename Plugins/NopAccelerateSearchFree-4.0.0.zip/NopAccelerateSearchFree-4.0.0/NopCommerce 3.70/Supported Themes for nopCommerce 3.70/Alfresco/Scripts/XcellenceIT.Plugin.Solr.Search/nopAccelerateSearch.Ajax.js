﻿/* *************************************************************************
// *                                                                       *
// * nopAccelerate - Solr Integration Extension for nopCommerce            *
// * Copyright (c) Xcellence-IT. All Rights Reserved.                      *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@nopaccelerate.com                                         *
// * Website: http://www.nopaccelerate.com                                 *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This  software is furnished  under a license  and  may  be  used  and *
// * modified  only in  accordance with the terms of such license and with *
// * the  inclusion of the above  copyright notice.  This software or  any *
// * other copies thereof may not be provided or  otherwise made available *
// * to any  other  person.   No title to and ownership of the software is *
// * hereby transferred.                                                   *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms  or  disassemble this software product or software product *
// * license.  Xcellence-IT may terminate this license if you don't comply *
// * with  any  of  the  terms and conditions set forth in  our  end  user *
// * license agreement (EULA).  In such event,  licensee  agrees to return *
// * licensor  or destroy  all copies of software  upon termination of the *
// * license.                                                              *
// *                                                                       *
// * Please see the  License file for the full End User License Agreement. *
// * The  complete license agreement is also available on  our  website at * 
// * http://www.nopaccelerate.com/terms/                                   *
// *                                                                       *
// ************************************************************************* */

$(document).on("keyup", ".npacc-filter-search", function () {

    //http://stackoverflow.com/questions/11083768/after-ajax-call-jquery-function-not-working-properly

    //Search filter
    SearchFilter($(this).val(), $(this).attr('id'));

    //Store text in browser
    WebStorageFilter($(this).val(), $(this).attr('id'), true);

});
$(document).ready(function () {
    ClearWebStorageFilter();

    //Lazy Loading
    $("img.lazy").show().lazyload({
        effect: "fadeIn"
    });

});

function UpdateQueryString(key, value, url) {
    if (!url) url = window.location.href;
    var re = new RegExp("([?|&])" + key + "=.*?(&|#|$)(.*)", "gi");


    if (re.test(url)) {
        if (typeof value !== 'undefined' && value !== null)
            return url.replace(re, '$1' + key + "=" + value + '$2$3');
        else {
            return url.replace(re, '$1$3').replace(/(&|\?)$/, '');
        }
    }
    else {
        if (typeof value !== 'undefined' && value !== null) {
            var separator = url.indexOf('?') !== -1 ? '&' : '?',
                hash = url.split('#');
            url = hash[0] + separator + key + '=' + value;
            if (hash[1]) url += '#' + hash[1];
            return url;
        }
        else
            return url;
    }
}

//Display text of particular filter search text box
function DisplayFilterSearchBoxValue() {
    $(".npacc-filter-search").each(function () {
        WebStorageFilter(null, $(this).attr("id"), false);
    });
}

//Collapse filter 
function SlideUpDown(divId, arrowId) {
    if ($('#' + divId).is(':visible')) {
        $('#' + divId).slideUp("slow");
        $('#' + arrowId).attr('class', 'arrow rotate');
    }
    else {
        $('#' + divId).slideDown("slow");
        $('#' + arrowId).attr('class', 'arrow');
    }

}


//Clear all filter search text from browser
$("#npacc-clearAll").click(function () {
    ClearWebStorageFilter();
});


//Ajax call caching
var localCache = {
    timeout: 600000, //in milisecond
    data: {},
    remove: function (url) {
        delete localCache.data[url];
    },
    exist: function (url) {
        return !!localCache.data[url] && ((new Date().getTime() - localCache.data[url]._) < localCache.timeout);
    },
    get: function (url) {
        console.log('Getting in cache for url' + url);
        return localCache.data[url].data;
    },
    set: function (url, cachedData, callback) {
        localCache.remove(url);
        localCache.data[url] = {
            _: new Date().getTime(),
            data: cachedData
        };
        if ($.isFunction(callback)) callback(cachedData);
    }
};

function callAjax(url, expire) {
    $('#npacc-ajax-loading').show(); //Show  ajax loader
    $.ajax({
        url: url,
        type: 'POST',
        cache: false,
        async: true,
        beforeSend: function () {
            if (localCache.exist(url)) {
                oldDataReplaceWithNew(localCache.get(url));
                return false;
            }
            return true;
        },
        complete: function (jqXHR, textStatus, callbackFunction) {

            //call QuickView Function Edit by vatsal 9/13/2016
            $.getScript(location.protocol + "//" + location.host + '/Plugins/SevenSpikes.Nop.Plugins.QuickView/Scripts/QuickView.min.js', function () {
                AddQuickViewButtons();
                $(".quick-view-button").click(function () {
                    //Retrive product id and pass into QuickView function
                    RetrieveQuickViewData($(this).closest(".product-item").data('productid'));
                });

            });
            // QickView popup close on Esc by vatsal 9/13/2016
            $(document).keyup(function (e) {
                if (e.keyCode == 27) { // escape key maps to keycode `27`
                    $(".k-overlay").css("display", "none");
                }
            });

            // QickView popup close on by vatsal 9/13/2016
            $(".k-window-actions").click(function (e) {
                var i = $(".quickViewWindow").data("kendoWindow");
                void 0 != i && "" != i.content() && i.close()
            });

            $.getScript(location.protocol + "//" + location.host + '/Plugins/SevenSpikes.Nop.Plugins.AjaxCart/Scripts/AjaxCart.min.js', function () {
                ajaxCartAllowedQuantitiesHover();
            });

            $.getScript(location.protocol + "//" + location.host + '/Plugins/SevenSpikes.Nop.Plugins.SalesCampaigns/Scripts/SaleCampaigns.min.js', function () {
            });

            $.getScript(location.protocol + "//" + location.host + '/Plugins/SevenSpikes.Nop.Plugins.ProductRibbons/Scripts/ProductRibbons.min.js', function () {

            });
        },
        success: function (result) {
            if (expire != undefined) {
                localCache.timeout = expire;
            }
            else { localCache.timeout = 600000; }
            localCache.set(url, result, oldDataReplaceWithNew);
            //ribbon();
        }
    });
}

function ribbon() {
    ! function (t, r, o) {
        function e() {
            var t = ".product-ribbon",
                o = sevenSpikes.getAttrValFromDom(u, "data-productPagePicturesParentContainerSelector"),
                e = [],
                a = {},
                d = sevenSpikes.getAttrValFromDom(u, "data-productId");
            if (d && d > 0 && o) {
                var n = r(o).find(t);
                n && 0 !== n.length || (a.productId = d, a.productElement = r(o))
            }
            return r(i).each(function () {
                var o = r(this).find(t);
                if (!o || 0 === o.length) {
                    var a = r(this).attr("data-productid");
                    if (a && a > 0) {
                        var d = {
                            productId: a,
                            productElement: r(this)
                        };
                        e.push(d)
                    }
                }
            }), {
                productPage: a,
                categoryPageProducts: e
            }
        }

        function a(t, r) {
            if (r && r.productPage && r.productPage.productId && d(t, r.productPage, !0), r && r.categoryPageProducts && r.categoryPageProducts.length > 0)
                for (var o = 0; o < r.categoryPageProducts.length; o++) {
                    var e = r.categoryPageProducts[o];
                    d(t, e)
                }
        }

        function d(t, o, e) {
            var a = "";
            if (o.productElement) {
                if (e) {
                    if (a = sevenSpikes.getAttrValFromDom(u, "data-productPageBugPictureContainerSelector"), !a) return
                } else if (a = sevenSpikes.getAttrValFromDom(u, "data-productBoxPictureContainerSelector"), !a) return;
                var d = o.productElement.find(a);
                if (d && o.productId && o.productId > 0) {
                    var n, i = o.productId;
                    n = e ? r(t).filter("div[data-productId='" + i + "']") : r(t).filter("a[data-productId='" + i + "']"), n && n.length > 0 && (r(d).wrap('<div class="' + c + '"></div>'), r(d).after(n))
                }
            }
        }

        function n() {
            return sevenSpikes.getAttrValFromDom("#product-ribbon-info", "data-retrieveproductribbonsurl")
        }
        var c = "ribbon-wrapper",
            u = "#product-ribbon-info",
            i = sevenSpikes.getAttrValFromDom(u, "data-productBoxSelector");
        i && (t.showRibbons = function () {
            var t = 0,
                o = [],
                d = e();
            if (d && d.productPage && d.productPage.productId && (t = d.productPage.productId), d && d.categoryPageProducts && d.categoryPageProducts.length > 0)
                for (var c = 0; c < d.categoryPageProducts.length; c++) {
                    var u = d.categoryPageProducts[c];
                    u.hasOwnProperty("productId") && o.push(u.productId)
                }
            if (t || 0 !== o.length) {
                r.isNumeric(t) || (t = 0);
                var i = {
                    productPageId: t,
                    categoryPageIds: o
                },
                    p = n();
                r.ajax({
                    type: "POST",
                    data: r.toJSON(i),
                    contentType: "application/json; charset=utf-8",
                    url: p
                }).done(function (t) {
                    t && (a(t, d), r.event.trigger({
                        type: "nopProductRibbonsLoadingCompleteEvent"
                    }))
                })
            }
        }, t.showRibbons())
    }(window.nopProductRibbons = window.nopProductRibbons || {}, jQuery), $(document).on("nopAjaxFiltersFiltrationCompleteEvent", nopProductRibbons.showRibbons)
}

function oldDataReplaceWithNew(data) {
    $('#npacc-search').replaceWith(data);
    $('#npacc-ajax-loading').hide();
    if (($('.pager').find('li').text() == "") && ($('#product-grid').length > 0)) {
        $('#product-grid').jscroll.destroy();
    }
    var n = $("input:checked").length;
    var tempURL = window.location.href.toLowerCase();
    if (tempURL.indexOf("as=true") != -1) {
        if (n > 1) {
            $('#npacc-clearAll').attr('style', 'display:block;');
        }
    }
    else {
        if (n > 0) {
            $('#npacc-clearAll').attr('style', 'display:block;');
        }
    }
    DisplayFilterSearchBoxValue();
    if (typeof (keepPriceRangeAfterRefresh) !== 'undefined') {
        keepPriceRangeAfterRefresh(); //Keeping price range selection after ajax call..
    }
    //Lazy Loading
    $("img.lazy").show().lazyload({
        effect: "fadeIn"
    });
    $(window).trigger("scroll");
}

//start: removable tag filters
function prepareSpecificationFilterTags(url) {
    var filterString = '';
    $('ul#tagsList').html(filterString);

    if (url) {
        var queryAttributes = url.split('?')[1];
        queryAttributes = queryAttributes.split('&');
        queryAttributes.forEach(function (specAttr) {
            var repSeperator = specAttr.replace(new RegExp("%3a", 'g'), ':').replace(new RegExp("%2c", 'g'), ',').replace(new RegExp("%7c", 'g'), '|').replace(new RegExp("%3A", 'g'), ':').replace(new RegExp("%2C", 'g'), ',').replace(new RegExp("%7C", 'g'), '|');

            var IsSecification = (repSeperator.indexOf("specs=") >= 0);
            var IsCategory = (repSeperator.indexOf("category=") >= 0);
            var IsVendor = (repSeperator.indexOf("vendor=") >= 0);
            var IsManufacturer = (repSeperator.indexOf("manufacturer=") >= 0);
            var IsRating = (repSeperator.indexOf("rating=") >= 0);
            if ((IsSecification) || (IsCategory) || (IsVendor) || (IsManufacturer)) {
                repSeperator = repSeperator.replace("specs=", "").replace("category=", "").replace("vendor=", "").replace("manufacturer=", "");
                var selOptions = repSeperator.split("||");
                selOptions.forEach(function (tag) {
                    if (tag) {
                        var filterPair = tag;
						var value = "";
						tag = replaceAllString(tag, "+", " ").replace("pa_", "").replace("f_", "").replace("%3A", ':').split(':');
                        // remove !! from tag
						if (tag[1].indexOf("!!") > 0) {
						    tag[1] = new String(tag[1]);
						    var indexOfPinch = tag[1].indexOf("!!");
						    var test = tag[1].substring(0, indexOfPinch);
						    tag.splice(1, 0, test);
						}
                        filterString += '<li><input type="hidden" value="' + filterPair + '" class="filterPair" /><span class="tag" title="Remove This Filter"><span>' + decodeURIComponent(tag[0]) + '</span> : ';

                        if (IsSecification) {
                            if (tag[1].indexOf("%23") >= 0) {
                                value = tag[1].split('%23');
                                filterString += '<span class="sSpecification">' + decodeURIComponent(value[0]) + '</span><span class="remove">x</span></span></li>';
                            }
                            else { filterString += '<span class="sSpecification">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>'; }
                        } else if (IsCategory) {
                            filterString += '<span class="sCategory">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        } else if (IsVendor) {
                            filterString += '<span class="sVendor">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        } else if (IsManufacturer) {
                            filterString += '<span class="sManufacturer">' + decodeURIComponent(tag[1]) + '</span><span class="remove">x</span></span></li>';
                        }
                    }
                });
            } else if (repSeperator.indexOf("stock=exclude_out_of_stock_products") >= 0) {
                var tag = "Exclude Out Of Stock";
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Availability</span> : ';
                filterString += '<span class="sStock">' + tag + '</span><span class="remove">x</span></span></li>';
            } else if (repSeperator.indexOf("stock=include_out_of_stock_products") >= 0) {
                var tag = "Include Out Of Stock";
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Availability</span> : ';
                filterString += '<span class="sStock">' + tag + '</span><span class="remove">x</span></span></li>';
            } else if (repSeperator.indexOf("rating=") >= 0) {
                repSeperator = repSeperator.replace("rating=", "");
                var tag = repSeperator;
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Rating</span> : ';
                filterString += '<span class="sRating">' + tag + '</span><span class="remove">x</span></span></li>';
            } else if (repSeperator.indexOf("price=") >= 0) {
                repSeperator = repSeperator.replace("price=", "");
                var tag = repSeperator;
                filterString += '<li><span class="tag" title="Remove This Filter"><span>Price</span> : ';
                filterString += '<span class="sPrice">' + tag + '</span><span class="remove">x</span></span></li>';
            }
        });

        $('ul#tagsList').append(filterString);
    }
}
function replaceAllString(string, find, replace) {
    //custom funcrion to replace all the occurences of string
    var str = string.replace(new RegExp(escapeRegExp(find), 'g'), replace);
    return str;
}
function escapeRegExp(string) {
    return string.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
}
function removeParameter(url, parameter) {
    var urlparts = url.split('?');

    if (urlparts.length >= 2) {
        var urlBase = urlparts.shift(); //get first part, and remove from array
        var queryString = urlparts.join("?"); //join it back up

        var prefix = encodeURIComponent(parameter) + '=';
        var pars = queryString.split(/[&;]/g);
        for (var i = pars.length; i-- > 0;)               //reverse iteration as may be destructive
            if (pars[i].lastIndexOf(prefix, 0) !== -1)   //idiom for string.startsWith
                pars.splice(i, 1);
        url = urlBase + '?' + pars.join('&');
    }
    return url;
}
//end: removable tag filters

//Clear all filter search text from browser
function ClearWebStorageFilter() {
    if (typeof (Storage) !== "undefined") {
        sessionStorage.clear();
    }
}
//Store filter search text in browser
function WebStorageFilter(keyword, id, isAjaxRequest) {
    var sessionStorageId = "sessionStorageId-" + id;

    if (!isAjaxRequest) {

        if (typeof (Storage) !== "undefined") {

            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                $("#" + id).val(sessionStorage[sessionStorageId]);
                SearchFilter(sessionStorage[sessionStorageId], id);
            }
        }
    }
    else {
        if (typeof (Storage) !== "undefined") {
            if (sessionStorage[sessionStorageId] !== "undefined" && sessionStorage[sessionStorageId] !== "") {
                sessionStorage[sessionStorageId] = keyword;
            }
            else {
                sessionStorage[sessionStorageId] = "";
                sessionStorage[sessionStorageId] = keyword;
            }
        }
    }
}

//Search in filter
function SearchFilter(keyword, id) {
    var found = false;
    $("#" + id + "-item li").each(function (li) {
        var originalText = $(this).find("span").attr("original");
        var regExp = new RegExp(keyword, 'i');
        if (regExp.test(originalText)) {
            $(this).show();

            //Highlights searched text
            $oldcontent = $(this).find("span").attr("original");
            $(this).find("span").html($oldcontent.replace(regExp.exec(originalText), '<em class="matched">' + regExp.exec(originalText) + '</em>'));

        }
        else {
            $(this).hide();
        }
    });
}

// fix for ie8 printed checkbox bug using jquery
//http://stackoverflow.com/questions/1414748/internet-explorer-8-and-checkbox-css-problem
$('input[type=checkbox]').live('change', function () {
    if ($(this).is(':checked')) {
        $(this).attr('checked', true);
    } else {
        $(this).attr('checked', false);
    }
});

function npAccFiltersPushStateUrl(stateUrl) {
    manualStateChange = false;
    History.pushState({ loadUrl: stateUrl, rand: Math.random() }, document.title, stateUrl);
    return false;
}

//function called when back and forward button click of any browser
$(function () {
    // history.js
    History.Adapter.bind(window, 'statechange', function () {
        var State = History.getState();
        var url = State.data.loadUrl == 'undefined' ? State.data.loadUrl : State.url;
        if (typeof (manualStateChange) !== 'undefined' && manualStateChange == true) {
            callAjax(url);
        }
        else if (typeof (State.data.loadUrl) == 'undefined') {
            callAjax(url);
        }
        manualStateChange = true;
        return false;
    });
});