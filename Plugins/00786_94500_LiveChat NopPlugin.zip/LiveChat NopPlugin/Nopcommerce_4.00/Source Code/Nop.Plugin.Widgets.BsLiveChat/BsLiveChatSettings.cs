﻿
using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.BsLiveChat
{
    public class BsLiveChatSettings : ISettings
    {
       
        public string TrackingScript { get; set; }
        
    }
}