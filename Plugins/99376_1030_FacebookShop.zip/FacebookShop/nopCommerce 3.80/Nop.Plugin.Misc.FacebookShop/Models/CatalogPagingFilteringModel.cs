﻿using Nop.Web.Framework.UI.Paging;

namespace Nop.Plugin.Misc.FacebookShop.Models
{
    //just a simplified copy of \Nop.Web\Models\Catalog\CatalogPagingFilteringModel.cs
    public partial class CatalogPagingFilteringModel : BasePageableModel
    {
    }
}