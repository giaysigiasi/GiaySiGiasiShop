﻿using Nop.Web.Framework.Mvc;

namespace Nop.Plugin.Misc.FacebookShop.Models
{
    public partial class FooterModel : BaseNopModel
    {
        public string StoreName { get; set; }
    }
}