﻿namespace Nop.Plugin.Misc.FacebookShop.Models
{
    public class RenderCategoryLineModel
    {
        public CategoryModel Category { get; set; }
        public int Level { get; set; }
        public bool LastItem { get; set; }
    }
}
