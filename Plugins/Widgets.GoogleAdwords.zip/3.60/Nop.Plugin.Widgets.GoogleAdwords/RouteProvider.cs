﻿using System.Web.Mvc;
using System.Web.Routing;
using Nop.Web.Framework.Mvc.Routes;

namespace Nop.Plugin.Widgets.GoogleAdwords
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(RouteCollection routes)
        {
            routes.MapRoute("Plugin.Widgets.GoogleAdwords.Configure",
                 "Plugins/WidgetsGoogleAdwords/Configure",
                 new { controller = "WidgetsGoogleAdwords", action = "Configure" },
                 new[] { "Nop.Plugin.Widgets.GoogleAdwords.Controllers" }
            );

            //routes.MapRoute("Plugin.Widgets.GoogleAdwords.PublicInfo",
            //     "Plugins/WidgetsGoogleAdwords/PublicInfo",
            //     new { controller = "WidgetsGoogleAdwords", action = "PublicInfo" },
            //     new[] { "Nop.Plugin.Widgets.GoogleAdwords.Controllers" }
            //);
        }
        public int Priority
        {
            get
            {
                return 0;
            }
        }
    }
}
