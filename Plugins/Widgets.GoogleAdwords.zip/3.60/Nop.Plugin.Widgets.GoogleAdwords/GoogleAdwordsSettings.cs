﻿
using Nop.Core.Configuration;

namespace Nop.Plugin.Widgets.GoogleAdwords
{
    public class GoogleAdwordsSettings : ISettings
    {

        public string ConversionId { get; set; }
        public string ConversionLabel { get; set; }
        public string ConversionScript { get; set; }
        public string RemarketingScript { get; set; }      
    }
}