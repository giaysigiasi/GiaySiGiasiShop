using System.Collections.Generic;
using System.Web.Routing;
using Nop.Core.Domain.Cms;
using Nop.Core.Plugins;
using Nop.Services.Cms;
using Nop.Services.Configuration;
using Nop.Services.Localization;

namespace Nop.Plugin.Widgets.GoogleAdwords
{
    /// <summary>
    /// GoogleAdwords
    /// </summary>
    public class GoogleAdwordsPlugin : BasePlugin, IWidgetPlugin
    {
        public const string DEFAULT_CONVERSION_SCRIPT = @"<!-- Google code for Adwords conversion -->
<script type=""text/javascript"">
    var google_tag_params = {
        ecomm_prodid: {PRODID},
        ecomm_pagetype: {PAGETYPE},
        ecomm_totalvalue: {VALUE},
    };
    var google_conversion_id = {GOOGLECONVERSIONID};
    var google_conversion_language = ""en"";
    var google_conversion_format = ""3"";
    var google_conversion_color = ""ffffff"";
    var google_conversion_label = ""{GOOGLECONVERSIONLABEL}"";
    var google_conversion_value = {VALUE};
    var google_custom_params = window.google_tag_params;
    var google_remarketing_only = false;
</script>
<script type=""text/javascript"" src=""http://www.googleadservices.com/pagead/conversion.js""> </script>
<noscript>
    <div style=""display:inline;"">
        <img height=""1"" width=""1"" style=""border-style:none;"" alt="""" src=""http://www.googleadservices.com/pagead/conversion/{GOOGLECONVERSIONID}/?value={VALUE}&label={GOOGLECONVERSIONLABEL}&amp;guid=ON&amp;script=0""/>
    </div>
</noscript> ";

        public const string DEFAULT_REMARKETING_SCRIPT = @"<!-- Code Google for Adwords remarketing -->
<script type=""text/javascript"">
    var google_tag_params = {
        ecomm_category: {CATEGORYNAME},
        ecomm_prodid: {PRODID},
        ecomm_pagetype: {PAGETYPE},
        ecomm_totalvalue: {VALUE},
    };
    /* <![CDATA[ */
    var google_conversion_id = {GOOGLECONVERSIONID};
    var google_custom_params = window.google_tag_params;
    var google_remarketing_only = true;
    /* ]]> */
</script>
<script type=""text/javascript"" src=""http://www.googleadservices.com/pagead/conversion.js""> </script>
<noscript>
    <div style=""display:inline;"">
        <img height=""1"" width=""1"" style=""border-style:none;"" alt="""" src=""http://googleads.g.doubleclick.net/pagead/viewthroughconversion/{GOOGLECONVERSIONID}/?value=0&amp;guid=ON&amp;script=0""/>
    </div>
</noscript>";

        private readonly ISettingService _settingService;
        private readonly GoogleAdwordsSettings _googleAdwordsSettings;

        public GoogleAdwordsPlugin(ISettingService settingService,
            GoogleAdwordsSettings googleAdwordsSettings)
        {
            this._settingService = settingService;
            this._googleAdwordsSettings = googleAdwordsSettings;
        }

        /// <summary>
        /// Gets widget zones where this widget should be rendered
        /// </summary>
        /// <returns>Widget zones</returns>
        public IList<string> GetWidgetZones()
        {
            return new List<string>()
            { 
                "body_start_html_tag_after"
                //desktop version (you can also replace it with "head_html_tag")
                //"body_end_html_tag_before", 
                //mobile version
                //"mobile_body_end_html_tag_before" 
            };
        }

        /// <summary>
        /// Gets a route for provider configuration
        /// </summary>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetConfigurationRoute(out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "Configure";
            controllerName = "WidgetsGoogleAdwords";
            routeValues = new RouteValueDictionary() { { "Namespaces", "Nop.Plugin.Widgets.GoogleAdwords.Controllers" }, { "area", null } };
        }

        /// <summary>
        /// Gets a route for displaying widget
        /// </summary>
        /// <param name="widgetZone">Widget zone where it's displayed</param>
        /// <param name="actionName">Action name</param>
        /// <param name="controllerName">Controller name</param>
        /// <param name="routeValues">Route values</param>
        public void GetDisplayWidgetRoute(string widgetZone, out string actionName, out string controllerName, out RouteValueDictionary routeValues)
        {
            actionName = "PublicInfo";
            controllerName = "WidgetsGoogleAdwords";
            routeValues = new RouteValueDictionary()
            {
                {"Namespaces", "Nop.Plugin.Widgets.GoogleAdwords.Controllers"},
                {"area", null},
                {"widgetZone", widgetZone}
            };
        }

        /// <summary>
        /// Install plugin
        /// </summary>
        public override void Install()
        {
            var settings = new GoogleAdwordsSettings()
            {
                
                ConversionId = @"1000000000",

                ConversionScript = DEFAULT_CONVERSION_SCRIPT,
				RemarketingScript = DEFAULT_REMARKETING_SCRIPT,
                
            };
            _settingService.SaveSetting(settings);

            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.Configure.Description", @"
<p>adWords is a advertising and link auction service of Google that enables companies and individuals to promote their products, services and websites under a cost-per-click (CPC) model. <br />
The advertiser specifies the keywords that it wants to target, and how much it is willing to pay for each click.  <br />
The ads might appear on Google�s search results as well as AdSense units.</p>
<p>This plugin provides :</p>
<ul>
    <li>Conversion script for a purchased order on the checkout/completed page.</li>
    <li>Remarketing script which is injected on all pages according to https://support.google.com/adwords/answer/3103357?hl=en .</li>
</ul>

");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionId", "Google Adwords ID");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionId.Hint", "Enter Google Adwords ID (format: 1000000000)");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionLabel", "Google Adwords conversion label");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionLabel.Hint", "Enter Google Adwords conversion label (like: sDGxCM295gEQ7_K58wM)");

            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.LoadDefaultScript", "Reload default script");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionScript", "Conversion script");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionScript.Hint", "Paste the conversion tracking code generated by Google adwords here, and replace hard coded values by tokens. http will be automatically replaced with https if necessary.");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.RemarketingScript", "Remarketing script");
            this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.GoogleAdwords.RemarketingScript.Hint", "Paste the remarketing script here, and replace hard coded values by tokens. http will be automatically replaced with https if necessary.");


            base.Install();
        }

         ///<summary>
         ///Uninstall plugin
         ///</summary>
        public override void Uninstall()
        {
            _settingService.DeleteSetting<GoogleAdwordsSettings>();
            //locales
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.Configure.Description");            
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionId");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionId.Hint");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionLabel");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionLabel.Hint");

            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.LoadDefaultScript");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionScript");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.ConversionScript.Hint");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.RemarketingScript");
            this.DeletePluginLocaleResource("Plugins.Widgets.GoogleAdwords.RemarketingScript.Hint");

            base.Uninstall();
        }
    }
}
