﻿using System.Web.Mvc;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc;
using System.ComponentModel;
using System.Collections.Generic;

namespace Nop.Plugin.Widgets.GoogleAdwords.Models
{
    public class ConfigurationModel : BaseNopModel
    {
        public int ActiveStoreScopeConfiguration { get; set; }

        
        [NopResourceDisplayName("Plugins.Widgets.GoogleAdwords.ConversionId")]
        public string ConversionId { get; set; }
        public bool ConversionId_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.GoogleAdwords.ConversionLabel")]
        public string ConversionLabel { get; set; }
        public bool ConversionLabel_OverrideForStore { get; set; }

        [NopResourceDisplayName("Plugins.Widgets.GoogleAdwords.ConversionScript")]
        [AllowHtml]
        public string ConversionScript { get; set; }
        public bool ConversionScript_OverrideForStore { get; set; }
        
        [NopResourceDisplayName("Plugins.Widgets.GoogleAdwords.RemarketingScript")]
        [AllowHtml]
        public string RemarketingScript { get; set; }
        public bool RemarketingScript_OverrideForStore { get; set; }
       

        [AllowHtml]
        public string DefaultConversionScript { get; set; }
        [AllowHtml]
        public string DefaultRemarketingScript { get; set; }



    }
}