﻿var ima9inesNopFAQ = {
    init: function () {
        $('.faq_question').click(function () {
            if ($(this).parent().is('.open')) {
                $(this).closest('.faq').find('.faq_answer_container').animate({ 'height': '0' }, 150);
                $(this).closest('.faq').removeClass('open');
            } else {
                $(this).closest('.faq').addClass('open');
                var newHeight = $(this).closest('.faq').find('.faq_answer').height() + 'px';
                $(this).closest('.faq').find('.faq_answer_container').animate({ 'height': newHeight }, 150);
            }
        });
    }
};
ima9inesNopFAQ.init();