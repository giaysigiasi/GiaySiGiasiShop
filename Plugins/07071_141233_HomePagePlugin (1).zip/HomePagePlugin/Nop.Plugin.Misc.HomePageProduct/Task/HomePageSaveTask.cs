﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Nop.Core;
using Nop.Services.Localization;
using Nop.Services.Tasks;

namespace Nop.Plugin.Misc.HomePageProduct.Task
{
    public partial class HomePageSaveTask : ITask
    {
        private readonly ILanguageService _languageService;
        private readonly IStoreContext _storeContext;
        public HomePageSaveTask(ILanguageService languageService, IStoreContext storeContext)
        {
            _languageService = languageService;
            _storeContext = storeContext;
        }
        public void Execute()
        {
                var languages = _languageService.GetAllLanguages();
                string currentStoreLocation= _storeContext.CurrentStore.Url;
                string url = currentStoreLocation+ "HomePageProduct/PublicPage";
                using (var wc = new WebClient())
                {
                    wc.DownloadString(url);
                }
        }
    }
}
