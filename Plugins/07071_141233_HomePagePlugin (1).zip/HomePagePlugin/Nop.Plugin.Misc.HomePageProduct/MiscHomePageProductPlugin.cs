﻿using Nop.Core.Plugins;
using Nop.Plugin.Misc.HomePageProduct.Data;
using Nop.Plugin.Misc.HomePageProduct.Services;
using Nop.Services.Cms;
using Nop.Services.Localization;
using Nop.Web.Framework.Menu;
using System.Collections.Generic;
using System.Web.Routing;
using System.Linq;

namespace Nop.Plugin.Misc.HomePageProduct
{
    public class MiscHomePageProductPlugin : BasePlugin, IAdminMenuPlugin
    {
        #region Fields

        private readonly HomePageProductObjectContext _context;
        private readonly IHomePageProductService _preOrderService;
        private readonly ILocalizationService _localizationService;

        #endregion

        #region Ctr

        public MiscHomePageProductPlugin(HomePageProductObjectContext context, IHomePageProductService preOrderService, ILocalizationService localizationService)
        {
            _context = context;
            _preOrderService = preOrderService;
            _localizationService = localizationService;
        }

        #endregion

        #region Install / Uninstall

        public override void Install()
        {
            //resource
            //this.AddOrUpdatePluginLocaleResource("Plugins.Widgets.LivePersonChat.ButtonCode", "Button code(max 2000)");

            this.AddOrUpdatePluginLocaleResource("misc.homepageproduct.menu.text", "Manage HomePage Product");
            this.AddOrUpdatePluginLocaleResource("admin.common.addcategory", "Add Category");
            this.AddOrUpdatePluginLocaleResource("category.priority", "Category Priority");
            this.AddOrUpdatePluginLocaleResource("admin.addproduct", "Add Product");
            this.AddOrUpdatePluginLocaleResource("admin.addcategoryimage", "Add Categoryimage");
            this.AddOrUpdatePluginLocaleResource("category.addsubcategory", "Add Subcategory");
            this.AddOrUpdatePluginLocaleResource("category.deletecategoryfromhomepage", "Delete Category From Homepage");
            this.AddOrUpdatePluginLocaleResource("admin.catalog.bulkedit.fields.productname", "Product Name");
            this.AddOrUpdatePluginLocaleResource("admin.catalog.products.variants.fields.disablebuybutton", "Disable Buybutton");
            this.AddOrUpdatePluginLocaleResource("admin.catalog.bulkedit.fields.subcategoryname", "Subcategory Name");
            this.AddOrUpdatePluginLocaleResource("Admin.Common.UpdateCategoryPriority", "Update Category Priority");
            this.AddOrUpdatePluginLocaleResource("Admin.CommonHomePageCancle.Cancle", "Cancle");





            //install db
            _context.InstallSchema();

            //base install
            base.Install();
        }
        /// <summary>
        /// Uninstall plugin
        /// </summary>
        public override void Uninstall()
        {
            //settings
            //_settingService.DeleteSetting<FroogleSettings>();

            //data
            _context.Uninstall();

            this.DeletePluginLocaleResource("misc.homepageproduct.menu.text");
            this.DeletePluginLocaleResource("admin.common.addcategory");
            this.DeletePluginLocaleResource("category.priority");
            this.DeletePluginLocaleResource("admin.addproduct");
            this.DeletePluginLocaleResource("admin.addcategoryimage");
            this.DeletePluginLocaleResource("category.addsubcategory");
            this.DeletePluginLocaleResource("category.deletecategoryfromhomepage");
            this.DeletePluginLocaleResource("admin.catalog.bulkedit.fields.productname");
            this.DeletePluginLocaleResource("admin.catalog.products.variants.fields.disablebuybutton");
            this.DeletePluginLocaleResource("admin.catalog.bulkedit.fields.subcategoryname");
            this.DeletePluginLocaleResource("Admin.Common.UpdateCategoryPriority");
            this.DeletePluginLocaleResource("Admin.CommonHomePageCancle.Cancle");


            base.Uninstall();
        }

        #endregion

        #region Menu Builder

        public bool Authenticate()
        {
            return true;
        }
        #endregion


        public void ManageSiteMap(SiteMapNode rootNode)
        {
            var menuItem = new SiteMapNode()
            {
                SystemName = "Misc.HomePageProduct",
                Title = _localizationService.GetResource("Misc.HomePageProduct.Menu.Text"),
                Visible = true,
                Url = "~/Plugin/Misc/HomePageProduct/CategoryAdd",
                RouteValues = new RouteValueDictionary() { { "area", "Admin" } },
            };
            var pluginNode = rootNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Third party plugins");
            if (pluginNode != null)
                pluginNode.ChildNodes.Add(menuItem);
            else
                rootNode.ChildNodes.Add(menuItem);
        }


    }
}