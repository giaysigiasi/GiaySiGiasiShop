1. 'Nop.Plugin.Feed.PriceGrabber' directory contains source code.
2. 'Feed.PriceGrabber' contains binaries. Just drop it into \Plugins directory on your server.