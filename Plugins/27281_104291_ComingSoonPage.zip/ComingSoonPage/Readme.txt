1. 'Nop.Plugin.Misc.ComingSoonPage' directory contains source code.
2. 'Misc.ComingSoonPage' contains binaries. Just drop it into \Plugins directory on your server.
