GrandNode Theme for nopCommerce 3.90
version: 3.90.0.5

What`s new in 3.90?
 Possibility to choose predefined store closed page
 Possibility to choose predefined customer orders page
 Fixed address dropdown select 
 Fixed show pick up points on map 
 Fixed color menu active
 Made menu fixed
 
Predefined colors:
	Brackwhite
	Blue
	Bluegray
	Gray
	Green
	Lightblue
	Orange
	Purple
	Red
	Yellow

Fix 3.90.0.5:
 - added new setting to show side navigation
Fix 3.90.0.4:
 - support store admin reply review
 - plugin enable to fix menu and shopping cart

Fix 3.90.0.2:
 - resource string added to DayOfWeek of custom order datails page

Fix 3.81.9:
 - added possbility to change colors directly from admin panel (need install widget first).
 - may add own colors from admin panel.

Fix 3.81.6:
- estimate shipping fix
- back to top with color change
- back to top icon change
- define if use Materializee or Font Awesome Icon

Fix 3.81.2:
- password recovery
- css for menu haader
- color for desktop footer topic 
- added widget to choose color from admin panel
- rtl support for color change

Fix 3.80.7:
- selection colors
- product attributes
- private messages

Fix 3.80.4:
- search board basic area
- advanced board search button
- view all activ topics button
